# Hybrid Renewable Energy System Simulation

This project simulates a hybrid renewable energy system composed of solar PV, wind turbines, battery storage, and a diesel generator backup.

## Features

- Hourly simulation of solar and wind energy generation
- Battery storage dynamics
- Diesel generator as backup source
- Visualization of battery SOC and diesel usage

## Data

Synthetic weather data are provided for demonstration purposes.

## Requirements

```bash
pip install -r requirements.txt
```

## Run

```bash
python hybrid_simulation.py
```

## License

MIT License
