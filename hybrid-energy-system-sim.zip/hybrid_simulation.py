import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load data
solar_irradiance = pd.read_csv('data/solar_irradiance.csv')
wind_speed = pd.read_csv('data/wind_speed.csv')

# Constants
pv_efficiency = 0.2
pv_area = 10  # m^2
wind_turbine_radius = 1  # meters
air_density = 1.225  # kg/m^3
demand_per_hour = 3  # kWh
battery_capacity = 20  # kWh
battery_charge = 10  # initial state

# Storage
solar_power = []
wind_power = []
net_load = []
battery_state = []
diesel_used = []

hours = len(solar_irradiance)

for t in range(hours):
    G = solar_irradiance.iloc[t]['irradiance']
    v = wind_speed.iloc[t]['speed']

    Ps = pv_efficiency * pv_area * G / 1000
    A = np.pi * wind_turbine_radius**2
    Pw = 0.5 * air_density * A * v**3 / 1000

    total_gen = Ps + Pw
    net = total_gen - demand_per_hour

    # Battery + Diesel Logic
    if net >= 0:
        battery_charge = min(battery_charge + net, battery_capacity)
        diesel = 0
    else:
        needed = -net
        if battery_charge >= needed:
            battery_charge -= needed
            diesel = 0
        else:
            diesel = needed - battery_charge
            battery_charge = 0

    solar_power.append(Ps)
    wind_power.append(Pw)
    net_load.append(net)
    battery_state.append(battery_charge)
    diesel_used.append(diesel)

# Plotting
plt.figure(figsize=(10, 4))
plt.plot(battery_state, label='Battery Charge (kWh)')
plt.plot(diesel_used, label='Diesel Used (kWh)', color='red')
plt.xlabel('Time (hours)')
plt.ylabel('Energy (kWh)')
plt.title('Hybrid System Energy Flow')
plt.legend()
plt.grid()
plt.tight_layout()
plt.show()
